require("dotenv").config();

const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { generateRouter } = require("./routes/hairstyles");

const app = express();
const port = Number(process.env.PORT || 10000);

const allowedOrigins = (process.env.FRONTEND_ORIGIN || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Allow server-to-server/no-origin requests; otherwise allow only configured sites.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin is not allowed by H(Ai)R CORS policy."));
  },
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

app.get("/", (_req, res) => {
  res.json({ name: "H(Ai)R Backend", status: "running", health: "/api/health" });
});

app.get("/api/health", (_req, res) => {
  res.json({
    success: true,
    status: "ok",
    message: process.env.OPENAI_API_KEY ? "Backend online; AI key configured." : "Backend online; AI key is missing."
  });
});

app.use("/api/hairstyles", generateRouter);

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === "LIMIT_FILE_SIZE") {
      return res.status(413).json({ success: false, code: "FILE_TOO_LARGE", message: "Ukuran foto maksimal 10 MB." });
    }
    return res.status(400).json({ success: false, code: "INVALID_FILE", message: "Upload foto tidak valid." });
  }
  if (err.message && err.message.includes("Origin is not allowed")) {
    return res.status(403).json({ success: false, code: "CORS_BLOCKED", message: "Domain frontend belum diizinkan di konfigurasi backend." });
  }
  console.error("H(Ai)R backend error:", err.message || err);
  res.status(500).json({ success: false, code: "SERVER_ERROR", message: "Terjadi kesalahan pada backend H(Ai)R." });
});

app.listen(port, "0.0.0.0", () => {
  console.log(`H(Ai)R backend listening on port ${port}`);
});
