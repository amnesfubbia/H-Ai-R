const HAIRSTYLES = {
  textured_crop: {
    id: "textured_crop",
    name: "Textured Crop",
    instruction: "Create a realistic Textured Crop hairstyle: short textured hair on top, clean natural shorter sides, realistic hairline and natural transition."
  },
  low_fade: {
    id: "low_fade",
    name: "Low Fade",
    instruction: "Create a realistic Low Fade hairstyle: gradual fade beginning low around the sides and back, natural textured hair on top, realistic transition and hairline."
  },
  two_block: {
    id: "two_block",
    name: "Two Block",
    instruction: "Create a realistic modern Two Block hairstyle: longer textured hair on top, visibly shorter sides, natural volume and realistic hair transition."
  },
  classic_side_part: {
    id: "classic_side_part",
    name: "Classic Side Part",
    instruction: "Create a realistic Classic Side Part hairstyle: natural side part, moderate volume, neatly styled hair and realistic hairline."
  }
};
module.exports = { HAIRSTYLES };
