# H(Ai)R backend — petunjuk untuk GitHub + Render

Backend ini menerima permintaan dari `index.html`, lalu meminta model gambar OpenAI mengedit foto. API key hanya disimpan di Environment Variables layanan backend; jangan pernah memasukkannya ke HTML/GitHub.

## Susunan file

Unggah folder `backend` (isi ZIP ini) ke repository GitHub yang sama dengan `index.html`.

```text
H-Ai-R/
├── index.html
└── backend/
    ├── server.js
    ├── package.json
    ├── .env.example
    ├── README_ID.md
    ├── config/hairstyles.js
    └── routes/hairstyles.js
```

## Deploy lewat browser HP

1. Di GitHub repository `H-Ai-R`, unggah folder/file backend dengan struktur di atas, lalu Commit changes.
2. Buka https://render.com dan masuk/daftar.
3. Buat **New → Web Service**, hubungkan akun GitHub, lalu pilih repository `H-Ai-R`.
4. Isi **Root Directory**: `backend`
5. **Runtime/Language**: Node
6. **Build Command**: `npm install`
7. **Start Command**: `npm start`
8. Pilih plan yang tersedia dan perhatikan batas/biaya layanan sebelum membuat service.
9. Pada Environment Variables, tambahkan:
   - `FRONTEND_ORIGIN` = `https://amnesfubbia.github.io`
   - `OPENAI_API_KEY` = API key milikmu dari dashboard OpenAI
   - `OPENAI_IMAGE_MODEL` = `gpt-image-2`
10. Buat/deploy service. Setelah selesai, Render memberikan URL HTTPS seperti `https://nama-service.onrender.com`.
11. Buka situs GitHub Pages H(Ai)R, scroll ke **Pengaturan koneksi backend**, masukkan URL Render tersebut dan tekan **UJI KONEKSI**.
12. Jika tes menunjukkan backend online, pilih foto dan tekan **TRY HAIRSTYLE**.

## Catatan penting

- URL GitHub Pages yang diizinkan di CORS adalah `https://amnesfubbia.github.io`. Jika URL situsmu berbeda, ubah `FRONTEND_ORIGIN` agar sama persis dengan origin situs yang terlihat di address bar (tanpa path `/H-Ai-R/`).
- API key tidak boleh ditempel ke GitHub atau HTML.
- Model gambar API membutuhkan akses dan saldo/limit API yang sesuai; ChatGPT berlangganan tidak otomatis memberikan saldo API.
- Render free service dapat tidur setelah tidak aktif dan perlu waktu untuk bangun.
- Backend tidak menyimpan foto secara sengaja. Foto dikirim ke penyedia AI untuk proses pengeditan; jangan mengunggah foto orang lain tanpa izin.
- File upload memvalidasi MIME type dan ukuran, tetapi untuk aplikasi publik produksi perlu tambahan pemeriksaan signature file, rate limiting, dan perlindungan penyalahgunaan.
