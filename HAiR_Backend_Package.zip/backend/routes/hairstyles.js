const express = require("express");
const multer = require("multer");
const OpenAI = require("openai");
const { toFile } = require("openai/uploads");
const { HAIRSTYLES } = require("../config/hairstyles");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter(_req, file, callback) {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    if (!allowed.includes(file.mimetype)) {
      return callback(new Error("Format foto harus JPG, PNG, atau WEBP."));
    }
    callback(null, true);
  }
});

router.get("/", (_req, res) => {
  res.json({
    success: true,
    hairstyles: Object.values(HAIRSTYLES).map(({ id, name }) => ({ id, name }))
  });
});

router.post("/generate", upload.single("photo"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, code: "NO_PHOTO", message: "Pilih foto terlebih dahulu." });
  }

  const style = HAIRSTYLES[req.body.hairstyle];
  if (!style) {
    return res.status(400).json({ success: false, code: "INVALID_STYLE", message: "Pilihan hairstyle tidak dikenal." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ success: false, code: "AI_NOT_CONFIGURED", message: "API key AI belum dipasang di backend." });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 150000, maxRetries: 0 });
    const imageFile = await toFile(req.file.buffer, req.file.originalname || "photo.jpg", {
      type: req.file.mimetype
    });

    const prompt = [
      "Edit the supplied photograph to show a realistic hairstyle transformation.",
      "Change only the person's hair and hairstyle. Preserve the person's identity, facial features, skin, expression, head position, body, clothing, background, lighting, camera angle, and framing.",
      "Do not alter the face or other parts of the photograph. Make the hairstyle photorealistic, natural, and anatomically consistent with the person's head.",
      "Requested hairstyle: " + style.name + ". " + style.instruction,
      "Return one edited image."
    ].join(" ");

    const result = await client.images.edit({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
      image: imageFile,
      prompt,
      size: "1024x1024",
      n: 1
    });

    const b64 = result.data && result.data[0] && result.data[0].b64_json;
    if (!b64) throw new Error("Image API returned no image data.");

    // No user image is saved to disk or database. The generated result is returned as a data URL.
    res.json({
      success: true,
      style: { id: style.id, name: style.name },
      image: "data:image/png;base64," + b64
    });
  } catch (error) {
    console.error("AI image edit failed:", error.status || "", error.message || error);
    const status = error.status === 401 || error.status === 403 ? 502 : 502;
    const message = error.status === 429
      ? "Kuota atau batas penggunaan AI tercapai. Periksa billing dan limit API."
      : error.status === 401 || error.status === 403
        ? "API key AI tidak valid atau tidak memiliki akses ke model."
        : "AI gagal membuat hairstyle. Coba lagi nanti.";
    res.status(status).json({
      success: false,
      code: "AI_GENERATION_FAILED",
      message
    });
  }
});

module.exports = { generateRouter: router };
